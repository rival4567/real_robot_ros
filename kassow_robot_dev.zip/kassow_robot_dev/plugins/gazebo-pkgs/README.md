# gazebo-pkgs

A collection of tools and plugins for Gazebo.

Please also refer to [the wiki](https://github.com/JenniferBuehler/gazebo-pkgs/wiki) for more information.
